/* implementation of the class NodeRegion
 */