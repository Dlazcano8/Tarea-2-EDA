/* implementation of the class ListOfPoint2D
 */