/*
 Class NodeRegion
*/

namespace image {
	class NodeRegion{
	private:		
	public:		
	};
}
